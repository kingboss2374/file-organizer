🐐 File Organizer & Safe Delete – Python Scripts

Thank you for downloading these Python scripts!
They are designed to help you organize files automatically and delete files safely, either permanently or by sending them to the Recycle Bin.

This product is donation-based 💖 — if you find it useful, consider supporting the developer.

⚙️ Requirements

Windows

Python 3.11 or newer

Basic knowledge of running Python scripts in a terminal or VS Code

To check your Python version:

python --version

📁 Script 1: File Organizer (organizer.py)
What it does

Automatically sorts files into folders based on file extensions

Creates folders automatically if they do not exist

How to use

Run organizer.py

When asked, enter the full path of the folder you want to organize
Example:

C:\Users\Steven\Downloads


The script will:

Create folders (e.g. Documents)

Move matching files into them

File types included

By default:

.txt

.docx

.lua

You can edit the script to add more file types if you want.

⚠️ Only files are moved — folders are ignored.

🗑️ Script 2: Safe Delete (safe_delete.py)
(Supports Files AND Folders)
What it does

Deletes files or folders

Lets you choose between:

Permanent deletion (cannot be recovered)

Recycle Bin deletion (can be restored)

How to use

Run safe_delete.py

Enter the full path of the file OR folder you want to delete
Examples:

C:\Users\Steven\Documents\example.txt

C:\Users\Steven\OldFolder


Confirm deletion by typing yes

Choose deletion mode:

permanent → deletes forever

recycle → sends to Recycle Bin

How it works

Files are deleted safely

Folders (including folders with files inside) are supported

The script checks what you entered before deleting

Required library

This script uses send2trash.

Install it once:

pip install send2trash

⚠️ Important Warnings

Permanent deletion cannot be undone

Always double-check paths

Folders are deleted with all contents inside

Backup important data before use

💖 Support the Developer

This project is donation-based.
If these scripts helped you, please consider donating via Gumroad — every contribution helps me keep improving and building more tools.

Thank you for your support! 🐐🔥