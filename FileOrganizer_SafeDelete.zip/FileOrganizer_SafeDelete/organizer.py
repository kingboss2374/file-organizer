import os
import shutil

file = input("What is the path for the file u want to organize? ")

types = {
    "Documents":[".docx",".txt",".lua"],
    "Images":[".jpg", ".png", ".jpeg"],
    "Videos":[".mp4"]
}

for f in os.listdir(file):
    link = os.path.join(file, f)

    if os.path.isfile(link):

        for for_name, exstentions in types.items():
            link2 = os.path.join(file, for_name)

            if f.lower().endswith(tuple(exstentions)):
                os.makedirs(link2, exist_ok=True)
                shutil.move(link, link2)
                print("Files organized succefully✅")
                break