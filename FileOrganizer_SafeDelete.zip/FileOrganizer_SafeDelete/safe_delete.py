import os
import shutil
from send2trash import send2trash

while True:
    file_location = input("What is the path of the file u want to delete? ")
    if os.path.isfile(file_location) or os.path.isdir(file_location):
      ans = input("are u sure u want to delete this file? ")
      if ans == "yes":
         ans2 = input("do u want to permanetly delete this file if so write: 'permanent'? or delete it and keep it in recycle bin if so write: 'recycle'?")
         if ans2 == "permanent":
            if os.path.isdir(file_location):
             shutil.rmtree(file_location)
             print("Folder permenantely deleted")
            else:
              os.remove(file_location)
              print("Filse permenantely deleted")
         elif ans2 == "recycle":
            send2trash(file_location)
            print("Folder sent to recycle bin succefully")
         break
      elif ans == "no":
         print("Pls retsart and write the path of file u want to delete.")
         continue
    elif not os.path.isfile(file_location) or not os.path.isdir(file_location):
       print("Not a valid path for a file pls enter the path for a file")
       continue